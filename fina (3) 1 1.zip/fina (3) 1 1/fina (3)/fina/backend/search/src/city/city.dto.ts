

export class CityDto {

     
    id: string;

    
    cityname: string;
    

     
    code: string;

     
    // releaseDateTime: Date;

    
    // createDateTime: Date;

    
    // updateDateTime: Date;
}