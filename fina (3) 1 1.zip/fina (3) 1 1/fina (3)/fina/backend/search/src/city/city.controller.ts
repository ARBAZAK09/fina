import { Controller,Logger } from '@nestjs/common';
import { CityService } from './city.service';
import { Get,Param, Post, Body } from '@nestjs/common/decorators';
import { CityDto } from './city.dto';


@Controller('citydev')
export class CityController {
    logger = new Logger(CityController.name);

    constructor(private cityService: CityService) {}

    @Get('all')
    public async getAll() {
      this.logger.debug("Get all books");
      return await this.cityService.getAll();
    }
    @Get(':id')
    public async getOne(@Param() params: any): Promise<any> {
        this.logger.debug("Get book by id Request");
        return await this.cityService.getOne(params.id);
    }

    @Post()
    public async save(@Body() itembody: CityDto) {
        this.logger.debug("Saving book "+ itembody);
        return await this.cityService.save(itembody);
    }
}
