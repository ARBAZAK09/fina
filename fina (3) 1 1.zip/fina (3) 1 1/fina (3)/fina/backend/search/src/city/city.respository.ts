
import {Repository} from 'typeorm';


import {City} from 'src/model/city.entity'

export class CityRepository extends Repository<City> {

}