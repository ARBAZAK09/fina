import { Module } from '@nestjs/common';
import { CityService } from './city.service';
import { CityController } from './city.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { City } from 'src/model/city.entity';
import { CityRepository } from './city.respository';
@Module({

    imports: [TypeOrmModule.forFeature([City])],
    controllers: [CityController],
    
    providers: [CityRepository,CityService],
    exports :[CityService]
})
export class CityModule {}
