import { Injectable } from '@nestjs/common';
import { Logger } from '@nestjs/common/services';
import { City } from 'src/model/city.entity';
import { CityDto } from './city.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CityRepository } from './city.respository';


@Injectable()
export class CityService {
    logger = new Logger(CityService.name);
    
    constructor(@InjectRepository(City) private readonly repo: CityRepository) { }

    public async getAll() {
        this.logger.debug("Find all books from repository");
        return await this.repo.find();
    }

    public async getOne(id: string) {
        this.logger.debug("Find book with id in repository " + id);
        return await this.repo.findOne({
          where:{
            id:id,
          },
        });
    }

    public async save(book: CityDto) {
        this.logger.debug("Saving book " + book);
        return await this.repo.save(book);
    }
}
