import { Controller,Logger } from '@nestjs/common';
import { Get,Param, Post, Body } from '@nestjs/common/decorators';
import { ImageService } from './image.service';
import { ImageDto } from './image.dto';



@Controller('image')


export class ImageController {

    logger = new Logger(ImageController.name);

    constructor(private imageService: ImageService) {}

    @Get('all')
    public async getAll() {
      this.logger.debug("Get all books");
      return await this.imageService.getAll();
    }

    @Get(':id')
    public async getOne(@Param() params: any): Promise<any> {
        this.logger.debug("Get book by id Request");
        return await this.imageService.getOne(params.id);
    }

    @Post()
    public async save(@Body() itembody: ImageDto) {
        this.logger.debug("Saving book "+ itembody);
        return await this.imageService.save(itembody);
    }
}
