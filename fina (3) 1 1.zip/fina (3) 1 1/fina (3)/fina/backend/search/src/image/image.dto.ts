

export class ImageDto {

     
    id: string;

    
    name: string;
    

     
   

     
    // releaseDateTime: Date;

    
    // createDateTime: Date;

    
    // updateDateTime: Date;
}