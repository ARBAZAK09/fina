import { Injectable } from '@nestjs/common';
import { Logger } from '@nestjs/common/services';
import { Image } from 'src/model/image.entity';
import { ImageDto } from './image.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ImageRepository } from './image.repository';


@Injectable()
export class ImageService {
    logger = new Logger(ImageService.name);
    
    constructor(@InjectRepository(Image) private readonly repo: ImageRepository) { }

    public async getAll() {
        this.logger.debug("Find all books from repository");
        return await this.repo.find();
    }

    public async getOne(id: string) {
        this.logger.debug("Find book with id in repository " + id);
        return await this.repo.findOne({
          where:{
            id:id,
          },
        });
    }

    public async save(image: ImageDto) {
        this.logger.debug("Saving book " + image);
        return await this.repo.save(image);
    }

}
