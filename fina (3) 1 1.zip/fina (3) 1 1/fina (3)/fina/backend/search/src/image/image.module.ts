import { Module } from '@nestjs/common';
import { ImageService } from './image.service';
import { ImageController } from './image.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Image } from 'src/model/image.entity';
import { ImageRepository } from './image.repository';
@Module({

 
    imports: [TypeOrmModule.forFeature([Image])],
    controllers: [ImageController],
    
    providers: [ImageRepository,ImageService],
    exports :[ImageService]   




})
export class ImageModule {}
