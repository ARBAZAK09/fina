
import {Repository} from 'typeorm';


import {Image} from 'src/model/image.entity'

export class ImageRepository extends Repository<Image> {

}