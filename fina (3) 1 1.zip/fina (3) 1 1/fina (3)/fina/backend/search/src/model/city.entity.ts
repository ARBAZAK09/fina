
import { PrimaryGeneratedColumn, Column,Entity } from 'typeorm';


@Entity({ name: 'citydev'})
export class City {

    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column({ type: 'varchar', length: 300 })
    cityname: string;

    @Column({ type: 'varchar', length: 300 })
    code: string;

    // @CreateDateColumn({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP' })
    // releaseDateTime: Date;

    // @CreateDateColumn({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP' })
    // createDateTime: Date;

    // @UpdateDateColumn({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP' })
    // updateDateTime: Date;
}