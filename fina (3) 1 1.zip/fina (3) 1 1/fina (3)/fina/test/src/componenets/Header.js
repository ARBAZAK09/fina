import React from "react";
import { CiGlobe } from "react-icons/ci";
import {
  Navbar,
  Nav,
  Container,
  NavDropdown,
  Badge,
  Dropdown,
  DropdownButton,
} from "react-bootstrap";
import { useEffect, useState } from "react";
import axios from "axios";
import "./Head.css";
// import Minniklogo from './Minniklogo.png'

const imageUrl =
  "https://minnikimages.s3.amazonaws.com/Logo+Mark_white%403x+1+(1).png";

const Header = () => {
  const [searchResults, setSearchResults] = useState([]);

  useEffect(() => {
    // Named function "getCity"
    async function getCity() {
      try {
        const resp = await axios.get("http://localhost:5000/image/all");

        const searchResults = await resp.data;
        console.log(searchResults);

        setSearchResults(searchResults);
      } catch (err) {
        console.log("Error occured when fetching city");
      }
    }

    // Call named function
    getCity();
  }, []);
  const [language, setLanguage] = useState("");

  return (
    <>
      <Navbar bg="transparent" variant="dark" expand="lg" collapseOnSelect>
        <Container>
          <img src={imageUrl} width="181" height="37" alt="MINNIK" />
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="ms-auto align-items-end">
              <Nav.Link href="#partner-page" style={{ fontSize: "20px" }}>
                {
                  <>
                    {language === "Arabic" ? (
                      <>
                        {" "}
                        {searchResults
                          .filter(
                            (item) =>
                              item.id === "c91d7e5e-bcf2-11e6-869b-7df92533d2db"
                          )
                          .map((item) => (
                            <p key={item.id}> {item.name}</p>
                          ))}
                      </>
                    ) : (
                      <>
                        {searchResults
                          .filter(
                            (item) =>
                              item.id === "c11d4e2e-bcf2-11e6-869b-7df92533d2db"
                          )
                          .map((item) => (
                            <p key={item.id}> {item.name}</p>
                          ))}
                      </>
                    )}
                  </>
                }
              </Nav.Link>
              <Nav.Link href="#partner-page" style={{ fontSize: "20px" }}>
                {
                  <>
                    {language === "Arabic" ? (
                      <>
                        {" "}
                        {searchResults
                          .filter(
                            (item) =>
                              item.id === "c91d7e5e-bcf2-1116-869b-7df92533d2db"
                          )
                          .map((item) => (
                            <p key={item.id}> {item.name}</p>
                          ))}
                      </>
                    ) : (
                      <>
                        {searchResults
                          .filter(
                            (item) =>
                              item.id === "c91d8e5e-bcf2-11e6-869b-7df92533d2db"
                          )
                          .map((item) => (
                            <p key={item.id}> {item.name}</p>
                          ))}
                      </>
                    )}
                  </>
                }
              </Nav.Link>
              <Nav.Link href="#partner-page" style={{ fontSize: "20px" }}>
                {
                  <>
                    {language === "Arabic" ? (
                      <>
                        {" "}
                        {searchResults
                          .filter(
                            (item) =>
                              item.id === "c91d6e5e-bcf2-11e6-869b-7df92533d2db"
                          )
                          .map((item) => (
                            <p key={item.id}> {item.name}</p>
                          ))}
                      </>
                    ) : (
                      <>
                        {searchResults
                          .filter(
                            (item) =>
                              item.id === "c91d4e2e-bcf2-11e6-869b-7df92533d2db"
                          )
                          .map((item) => (
                            <p key={item.id}> {item.name}</p>
                          ))}
                      </>
                    )}
                  </>
                }
              </Nav.Link>
              <Nav.Link href="#partner-page" style={{ fontSize: "20px" }}>
                {
                  <>
                    {language === "Arabic" ? (
                      <>
                        {" "}
                        {searchResults
                          .filter(
                            (item) =>
                              item.id === "c91d4e5e-bcf2-11e6-861b-7df92533d2db"
                          )
                          .map((item) => (
                            <p key={item.id}> {item.name}</p>
                          ))}
                      </>
                    ) : (
                      <>
                        {searchResults
                          .filter(
                            (item) =>
                              item.id === "c91d4e5e-bcf2-11e6-869b-7df92533d2db"
                          )
                          .map((item) => (
                            <p key={item.id}> {item.name}</p>
                          ))}
                      </>
                    )}
                  </>
                }
              </Nav.Link>{" "}
              <Nav.Item style={{ position: "relative" }}>
                <i
                  className="fas fa-globe"
                  style={{
                    color: "white",
                    position: "absolute",
                    top: "50%",
                    transform: "translateY(-50%)",
                    left: "10px",
                  }}
                ></i>
                <select
                  style={{
                    appearance: "none",
                    backgroundColor: "transparent",
                    color: "white",
                    padding: "2px 10px",
                    border: "none",
                    cursor: "pointer",
                  }}
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                >
                  <option value="Eng">
                    {searchResults
                      .filter((item) => item.name === "Eng")
                      .map((item) => (
                        <p key={item.id}>{item.name}</p>
                      ))}
                  </option>
                  <option value="Arabic">
                    {searchResults
                      .filter((item) => item.name === "Arb")
                      .map((item) => (
                        <p key={item.id}>{item.name}</p>
                      ))}
                  </option>
                </select>
              </Nav.Item>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </>
  );
};

export default Header;
