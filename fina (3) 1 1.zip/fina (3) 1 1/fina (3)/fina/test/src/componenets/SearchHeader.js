import React,{useEffect,useState} from 'react';
import { faSearch, faMapMarker } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';



import './SearchHeader.css'
import axios from 'axios'

const SearchHeader = () => {
 
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const handleChange = (e) => {
    setSearchTerm(e.target.value);
  };
//Use Effect//
  useEffect(() => {

    // Named function "getCity"
    async function getCity() {
      try {
        const resp = await axios.get('http://localhost:5000/citydev/all')
       
        const searchResults = await (resp.data)
        console.log((searchResults))

        setSearchResults(searchResults)

        
       
      } catch (err) {
        console.log('Error occured when fetching city');
      }
    }
  
    // Call named function
    getCity();
  }, []);



  return (
   <div id='textcolorwhite'>
    <h2>Your Trusted Laundry Service Provider</h2>
    
    <h4 style={{marginTop: "30px"}}>Discover Top Laundry Services Near You</h4>
    <div className='search-bar-container'>
        
    <input id='search-text'type='text' placeholder="Search by area or store" className='search-input'
        value={searchTerm}
        onChange={handleChange}></input>
              {/* <FontAwesomeIcon icon={faSearch} className="search-icon" />
      <FontAwesomeIcon icon={faMapMarker} className="map-marker-icon" /> */}

    </div>


    <div id = 'searchresult'>
   {
      
       searchTerm && 
       
       searchResults.filter(item=>item.cityname.toLowerCase().startsWith(searchTerm.toLowerCase()) && item.cityname.toLowerCase() !== searchTerm.toLowerCase())
      .slice(0,5)
      .map((item)=><div key={item.id} onClick={(e)=>setSearchTerm(item.cityname)}>
      {item.cityname} <hr />

     
      </div>)
   }
    </div>
   </div>
  )
}

export default SearchHeader